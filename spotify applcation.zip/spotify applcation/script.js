const APIController = (function() {
    const clientId = '44d423bb4dae41c48d413bdd69a76cb5';
    const clientSecret = '01c659ca9fa346848afa8d7ed3eacf92';

    const _getToken = async () => {
        const result = await fetch('https://accounts.spotify.com/api/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Basic ' + btoa(clientId + ':' + clientSecret)
            },
            body: 'grant_type=client_credentials'
        });

        const data = await result.json();
        return data.access_token;
    };

    const _getGenres = async (token) => {
        const result = await fetch(`https://api.spotify.com/v1/browse/categories?locale=sv_US`, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });

        const data = await result.json();
        return data.categories.items;
    };

    const _getPlaylistByGenre = async (token, genreId) => {
        const limit = 10;

        const result = await fetch(`https://api.spotify.com/v1/browse/categories/${genreId}/playlists?limit=${limit}`, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });

        const data = await result.json();
        return data.playlists.items;
    };

    const _getTracks = async (token, tracksEndPoint) => {
        const limit = 10;

        const result = await fetch(`${tracksEndPoint}?limit=${limit}`, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });

        const data = await result.json();
        return data.items;
    };

    const _getTrack = async (token, trackEndPoint) => {
        const result = await fetch(`${trackEndPoint}`, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });

        const data = await result.json();
        return data;
    };

    const _getArtist = async (token, artistId) => {
        const result = await fetch(`https://api.spotify.com/v1/artists/${artistId}`, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });

        if (!result.ok) {
            throw new Error(`Failed to fetch artist data: ${result.status} - ${result.statusText}`);
        }

        const data = await result.json();
        return data;
    };

    const _search = async (token, query, types) => {
        const typeString = types.join(',');
    
        try {
            const result = await fetch(`https://api.spotify.com/v1/search?q=${query}&type=${typeString}`, {
                method: 'GET',
                headers: { 'Authorization': 'Bearer ' + token }
            });
    
            if (!result.ok) {
                throw new Error(`Search request failed: ${result.status} - ${result.statusText}`);
            }
    
            const data = await result.json();
            console.log('Search API Result:', data); 
            return data;
        } catch (error) {
            console.error('Error in _search:', error.message);
            throw error;
        }
    };

    const _getArtistAlbums = async (token, artistId) => {
        const result = await fetch(`https://api.spotify.com/v1/artists/${artistId}/albums`, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });
    
        if (!result.ok) {
            throw new Error(`Failed to fetch artist albums: ${result.status} - ${result.statusText}`);
        }
    
        const data = await result.json();
        return data;
    };

    return {
        getToken() {
            return _getToken();
        },
        getGenres(token) {
            return _getGenres(token);
        },
        getPlaylistByGenre(token, genreId) {
            return _getPlaylistByGenre(token, genreId);
        },
        getTracks(token, tracksEndPoint) {
            return _getTracks(token, tracksEndPoint);
        },
        getTrack(token, trackEndPoint) {
            return _getTrack(token, trackEndPoint);
        },
        getArtist(token, artistId) {
            return _getArtist(token, artistId);
        },
        search(token, query, types) {
            return _search(token, query, types);
        },
        getArtistAlbums(token, artistId) {
            return _getArtistAlbums(token, artistId);
        }
    };
})();

const UIController = (function() {
    const DOMElements = {
        selectGenre: '#select_genre',
        selectPlaylist: '#select_playlist',
        buttonSubmit: '#btn_submit',
        divSongDetail: '#song-detail',
        hfToken: '#hidden_token',
        divSonglist: '.song-list'
    };

    return {
        inputField() {
            return {
                genre: document.querySelector(DOMElements.selectGenre),
                playlist: document.querySelector(DOMElements.selectPlaylist),
                tracks: document.querySelector(DOMElements.divSonglist),
                submit: document.querySelector(DOMElements.buttonSubmit),
                songDetail: document.querySelector(DOMElements.divSongDetail)
            };
        },
        createGenre(text, value) {
            const html = `<option value="${value}">${text}</option>`;
            document.querySelector(DOMElements.selectGenre).insertAdjacentHTML('beforeend', html);
        },
        createPlaylist(text, value) {
            const html = `<option value="${value}">${text}</option>`;
            document.querySelector(DOMElements.selectPlaylist).insertAdjacentHTML('beforeend', html);
        },
        createTrack(id, name) {
            const html = `<a href="#" class="list-group-item list-group-item-action list-group-item-light" id="${id}">${name}</a>`;
            document.querySelector(DOMElements.divSonglist).insertAdjacentHTML('beforeend', html);
        },
        createTrackDetail(img, title, artist) {
            const detailDiv = document.querySelector(DOMElements.divSongDetail);
            detailDiv.innerHTML = '';
            const html =
                `<div class="row col-sm-12 px-0">
                    <img src="${img}" alt="">        
                </div>
                <div class="row col-sm-12 px-0">
                    <label for="Genre" class="form-label col-sm-12">${title}:</label>
                </div>
                <div class="row col-sm-12 px-0">
                    <label for="artist" class="form-label col-sm-12">By ${artist}:</label>
                </div>`;
            detailDiv.insertAdjacentHTML('beforeend', html);
        },
        resetTrackDetail() {
            this.inputField().songDetail.innerHTML = '';
        },
        resetTracks() {
            this.inputField().tracks.innerHTML = '';
            this.resetTrackDetail();
        },
        resetPlaylist() {
            this.inputField().playlist.innerHTML = '';
            this.resetTracks();
        },
        storeToken(value) {
            document.querySelector(DOMElements.hfToken).value = value;
        },
        getStoredToken() {
            return {
                token: document.querySelector(DOMElements.hfToken).value
            };
        }
    };
})();

// Update your existing JavaScript file with the following code

// Add a new function to handle the artist details
const _displayArtistDetails = (data) => {
    const artistDetailsDiv = document.getElementById('artistDetails');

    // Clear previous details
    artistDetailsDiv.innerHTML = '';

    if (data) {
        // Create HTML to display artist details
        const html = `
            <h3>${data.name}</h3>
            <p>Followers: ${data.followers.total}</p>
            <p>Genres: ${data.genres.join(', ')}</p>
            <p>Popularity: ${data.popularity}</p>
            <img src="${data.images[0].url}" alt="${data.name}">
        `;

        // Insert the HTML into the artistDetailsDiv
        artistDetailsDiv.innerHTML = html;
    } else {
        // Display a message if no data is available
        artistDetailsDiv.innerHTML = '<p>No artist details available.</p>';
    }
};



// Update your existing event listener for the getArtistForm
document.getElementById('getArtistForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    // Get the artist ID from the form
    const artistId = document.getElementById('artistId').value;

    try {
        // Fetch artist details using the _getArtist function
        const token = await APIController.getToken();
        const artistDetails = await APIController.getArtist(token, artistId);

        // Display artist details
        _displayArtistDetails(artistDetails);
    } catch (error) {
        console.error('Error fetching artist details:', error.message);
    }
});

const _displayArtistAlbums = (data) => {
    const artistAlbumsDiv = document.getElementById('artistAlbums');

    // Clear previous albums
    artistAlbumsDiv.innerHTML = '';

    if (data && data.items && data.items.length > 0) {
        // Create HTML to display artist albums
        const html = `<h3>Artist Albums:</h3>
                      <ul>`;
        
        data.items.forEach(album => {
            // Format the release date
            const releaseDate = new Date(album.release_date).toLocaleDateString();

            html += `<li>${album.name} - Released on ${releaseDate}</li>`;
        });

        html += `</ul>`;

        // Insert the HTML into the artistAlbumsDiv
        artistAlbumsDiv.innerHTML = html;
    } else {
        // Display a message if no albums are available
        artistAlbumsDiv.innerHTML = '<p>No artist albums available.</p>';
    }
};

// Update your existing event listener for the getArtistAlbumsForm
document.getElementById('getArtistAlbumsForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    // Get the artist ID from the form
    const artistIdAlbums = document.getElementById('artistIdAlbums').value;

    try {
        // Fetch artist albums using the Spotify API
        const token = await APIController.getToken();
        const artistAlbums = await APIController.getArtistAlbums(token, artistIdAlbums);

        // Display artist albums
        _displayArtistAlbums(artistAlbums);
    } catch (error) {
        console.error('Error fetching artist albums:', error.message);
    }
});


// Update your existing JavaScript file with the following code
const _search = async (token, query, types) => {
        const typeString = types.join(',');

        const result = await fetch(`https://api.spotify.com/v1/search?q=${query}&type=${typeString}`, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });

        const data = await result.json();
        return data;
    };
// Add a new function to handle the search results
// Update the existing _displaySearchResults function
const _displaySearchResults = (data) => {
    const searchResultsDiv = document.getElementById('searchResults');

    // Clear previous search results
    searchResultsDiv.innerHTML = '';

    if (data && data.tracks && data.tracks.items.length > 0) {
        // Create HTML to display search results
        const html = `<h3>Search Results:</h3>
                      <ul>`;

        data.tracks.items.forEach(item => {
            html += `<li>${item.name} - ${item.artists.map(artist => artist.name).join(', ')}</li>`;
        });

        html += `</ul>`;

        // Insert the HTML into the searchResultsDiv
        searchResultsDiv.innerHTML = html;
    } else {
        // Display a message if no results are available
        searchResultsDiv.innerHTML = '<p>No search results available.</p>';
    }
};


// Update your existing event listener for the spotifySearchForm
document.getElementById('spotifySearchForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    // Get the search query from the form
    const searchQuery = document.getElementById('searchQuery').value;

    // Get the selected search types
    const searchTypeSelect = document.getElementById('searchType');
    const selectedTypes = Array.from(searchTypeSelect.selectedOptions, option => option.value);

    try {
        // Fetch search results using the Spotify API
        const token = await APIController.getToken();
        const searchResults = await APIController.search(token, searchQuery, selectedTypes);
    
        // Log the structure of searchResults to the console
        console.log('Search API Result:', searchResults);
    
        // Check if the searchResults object has a 'tracks' property
        if (searchResults && searchResults.tracks) {
            // Display search results
            _displaySearchResults(searchResults);
        } else {
            console.error('Error fetching search results: Unexpected response format');
        }
    } catch (error) {
        console.error('Error fetching search results:', error.message);
    }
    
    
});



const APPController = (function(UICtrl, APICtrl) {
    const DOMInputs = UICtrl.inputField();

    const loadGenres = async () => {
        const token = await APICtrl.getToken();
        UICtrl.storeToken(token);
        const genres = await APICtrl.getGenres(token);
        genres.forEach(element => UICtrl.createGenre(element.name, element.id));
    };

    DOMInputs.genre.addEventListener('change', async () => {
        UICtrl.resetPlaylist();
        const token = UICtrl.getStoredToken().token;
        const genreSelect = UICtrl.inputField().genre;
        const genreId = genreSelect.options[genreSelect.selectedIndex].value;
        const playlist = await APICtrl.getPlaylistByGenre(token, genreId);
        playlist.forEach(p => UICtrl.createPlaylist(p.name, p.tracks.href));
    });


    DOMInputs.submit.addEventListener('click', async (e) => {
        e.preventDefault();
        UICtrl.resetTracks();
        const token = UICtrl.getStoredToken().token;
        const playlistSelect = UICtrl.inputField().playlist;
        const tracksEndPoint = playlistSelect.options[playlistSelect.selectedIndex].value;
        const tracks = await APICtrl.getTracks(token, tracksEndPoint);
        tracks.forEach(el => UICtrl.createTrack(el.track.href, el.track.name));
    });

    DOMInputs.tracks.addEventListener('click', async (e) => {
        e.preventDefault();
        UICtrl.resetTrackDetail();
        const token = UICtrl.getStoredToken().token;
        const trackEndpoint = e.target.id;
        const track = await APICtrl.getTrack(token, trackEndpoint);
        UICtrl.createTrackDetail(track.album.images[2].url, track.name, track.artists[0].name);
    });

    return {
        init() {
            console.log('App is starting');
            loadGenres();
        }
    };
})(UIController, APIController);

APPController.init();
